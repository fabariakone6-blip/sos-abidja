SOS ABIDJAN - automatisation pharmacies de garde

Le workflow GitHub Actions (.github/workflows/pharmacies-garde.yml) vérifie automatiquement
chaque lundi et le 1er du mois si le site UNPPCI répond. Il peut également être lancé
manuellement depuis GitHub Actions.

IMPORTANT: Ce premier workflow ne télécharge pas encore le PDF/programme de garde et ne
extrait pas les pharmacies. L'automatisation complète de la liste nécessite de repérer,
tester et valider le document source exact et son format. Le workflow n'écrase aucune liste
et ne prétend pas confirmer les pharmacies de garde.
